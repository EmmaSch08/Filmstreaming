<?php

// Verbindet sich mit der Datenbank über eine externe Datei
require dirname(__DIR__) . '/connect/connect.php';

// Überprüft, ob das Formular per POST-Methode abgesendet wurde
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Holt die Daten aus dem POST-Array, die im Formular eingegeben wurden
    $id = $_POST['id'];
    $name = $_POST['name'];
    $geburtsdatum = $_POST['geburtsdatum'];
    $nationalitaet = $_POST['nationalitaet'];

    // Debugging-Ausgabe der ID (wird normalerweise zum Testen verwendet und kann entfernt werden)
    echo $id;
    
    // Bereitet das SQL-Statement vor, um einen neuen Regisseur in die Datenbank einzufügen
    $stmt = $pdo->prepare('INSERT INTO `regisseur` (`id`, `name`, `geburtsdatum`, `nationalitaet`) 
                           VALUES (:id, :name, :geburtsdatum, :nationalitaet)');

    // Bindet die Werte der Variablen an die Platzhalter im SQL-Statement, um SQL-Injektionen zu vermeiden
    $stmt->bindValue(':id', $id);
    $stmt->bindValue(':name', $name);
    $stmt->bindValue(':geburtsdatum', $geburtsdatum);  // Achte darauf, dass hier die Spalte korrekt ist
    $stmt->bindValue(':nationalitaet', $nationalitaet);

    // Führt das SQL-Statement aus, um den Regisseur in die Datenbank einzufügen
    $stmt->execute();

    // Leitet den Benutzer nach dem erfolgreichen Einfügen zurück zur Index-Seite
    header('location:./index.php');
}

?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Regisseur hinzufügen</title>
    <!-- Bootstrap CSS für ein ansprechendes Layout -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <!-- Formular zur Eingabe der Regisseur-Daten -->
    <form action="" method="POST" class="border p-4 rounded shadow">
        <a href="./../regisseur/" class="btn btn-primary" style="float: right; margin: 5px;">X</a>

        
        <!-- Eingabefeld für die ID -->
        <div class="mb-3">
            <label for="id" class="form-label">ID:</label>
            <input type="text" id="id" name="id" class="form-control" required>
        </div>

        <!-- Eingabefeld für den Namen des Regisseurs -->
        <div class="mb-3">
            <label for="name" class="form-label">Name:</label>
            <input type="text" id="name" name="name" class="form-control" required>
        </div>

        <!-- Eingabefeld für das Geburtsdatum -->
        <div class="mb-3">
            <label for="geburtsdatum" class="form-label">Geburtsdatum:</label>
            <input type="date" id="geburtsdatum" name="geburtsdatum" class="form-control" required>
        </div>

        <!-- Eingabefeld für die Nationalität -->
        <div class="mb-3">
            <label for="nationalitaet" class="form-label">Nationalität:</label>
            <input type="text" id="nationalitaet" name="nationalitaet" class="form-control" required>
        </div>

        <!-- Absenden-Button für das Formular -->
        <button type="submit" class="btn btn-primary">Regisseur hinzufügen</button>
    </form>
</body>
</html>
