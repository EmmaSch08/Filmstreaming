<?php

// Verbindet sich mit der Datenbank über eine externe Datei
require dirname(__DIR__) . '/connect/connect.php';

// Vorbefüllen der Eingabefelder, wenn eine Update-Anfrage mit einer ID gestellt wird
if(isset($_GET['updateId'])){
    // Holt die ID aus der URL, um den Regisseur mit dieser ID zu bearbeiten
    $id = $_GET['updateId'];
    
    // Bereitet die SQL-Anweisung vor, um den Regisseur mit der gegebenen ID abzurufen
    $stmt = $pdo->prepare('SELECT * FROM `regisseur` WHERE `id`=:id');
    $stmt->bindValue(':id', $id); 
    $stmt->execute();

    // Holt das Ergebnis aus der Datenbank (nur ein Datensatz, daher verwenden wir fetch)
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Weist die Variablen mit den Werten aus der Datenbank zu
    $name = $result['name'];
    $geburtsdatum = $result['geburtsdatum'];
    $nationalitaet = $result['nationalitaet'];
}

// Update-Logik: Wenn das Formular abgesendet wird (POST-Methode)
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Holt die Daten aus dem Formular
    $id = $_POST['id'];
    $name = $_POST['name'];
    $geburtsdatum = $_POST['geburtsdatum'];
    $nationalitaet = $_POST['nationalitaet'];
    
    // Debugging-Ausgabe der ID (kann später entfernt werden)
    echo $id;
    
    // Bereitet die SQL-Anweisung vor, um die bestehenden Regisseur-Daten zu aktualisieren
    $stmt = $pdo->prepare('UPDATE `regisseur` SET `id`=:id, `name`=:name, `geburtsdatum`=:geburtsdatum
                           WHERE `id`=:id');

    // Bindet die Formulardaten an die Platzhalter in der SQL-Anweisung
    $stmt->bindValue(':id', $id);
    $stmt->bindValue(':name', $name);
    $stmt->bindValue(':geburtsdatum', $geburtsdatum); // Korrektur: Geburtsdatum in der Bindung
    $stmt->bindValue(':nationalitaet', $nationalitaet);

    // Führt die SQL-Anweisung aus
    $stmt->execute();

    // Leitet den Benutzer nach erfolgreicher Aktualisierung auf die Index-Seite weiter
    header('location:./index.php');
}

?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Regisseur ändern</title>
    <!-- Bootstrap für schönes Layout -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <!-- Überschrift für die Seite -->
    <h2 class="mb-4 text-center">Regisseur ändern</h2>
    
    <!-- Formular zur Aktualisierung des Regisseurs -->
    <form action="" method="POST" class="border p-4 rounded shadow">
        <a href="./../regisseur/" class="btn btn-primary" style="float: right; margin: 5px;">X</a>

        <!-- ID-Feld (nur zur Anzeige, nicht änderbar) -->
        <div class="mb-3">
            <label for="id" class="form-label">ID:</label>
            <input type="text" id="id" name="id" class="form-control" value="<?php echo $id ?>" readonly>
        </div>

        <!-- Eingabefeld für den Namen des Regisseurs -->
        <div class="mb-3">
            <label for="name" class="form-label">Name:</label>
            <input type="text" id="name" name="name" class="form-control" value="<?php echo $name ?>" required>
        </div>

        <!-- Eingabefeld für das Geburtsdatum -->
        <div class="mb-3">
            <label for="geburtsdatum" class="form-label">Geburtsdatum:</label>
            <input type="date" id="geburtsdatum" name="geburtsdatum" class="form-control" value="<?php echo $geburtsdatum ?>" required>
        </div>

        <!-- Eingabefeld für die Nationalität -->
        <div class="mb-3">
            <label for="nationalitaet" class="form-label">Nationalität:</label>
            <input type="text" id="nationalitaet" name="nationalitaet" class="form-control" value="<?php echo $nationalitaet ?>" required>
        </div>

        <!-- Absenden-Button -->
        <button type="submit" class="btn btn-primary w-100">Regisseur ändern</button>
    </form>
</body>
</html>
