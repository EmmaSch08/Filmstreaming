<?php

// Verbindet sich mit der Datenbank über eine externe Datei
require dirname(__DIR__) . '/connect/connect.php';

// Überprüft, ob eine 'deleteId' als GET-Parameter übergeben wurde
if(isset($_GET['deleteId'])) {
    $id = $_GET['deleteId']; // Speichert die zu löschende ID in der Variablen $id
    echo "deleteId auf " . $id . " gesetzt"; // Gibt die ID zur Bestätigung aus (nur für Debugging)
    
    // Bereitet die SQL-Abfrage vor, um den Datensatz mit der gegebenen ID zu löschen
    $stmt = $pdo->prepare('DELETE FROM `regisseur` WHERE `id`=:id');
    $stmt->bindValue(':id', $id); // Bindet den Wert der ID an die SQL-Abfrage, um SQL-Injections zu verhindern
    $stmt->execute(); // Führt die Abfrage aus

    // Leitet den Benutzer zurück zur Index-Seite nach dem Löschen
    header('location:./index.php');
}

?>
