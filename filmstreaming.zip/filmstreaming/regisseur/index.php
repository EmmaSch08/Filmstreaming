<?php

// Verbindet sich mit der Datenbank über eine externe Datei
require dirname(__DIR__) . '/connect/connect.php';

// Bereitet eine SQL-Abfrage vor, um alle Regisseure aus der Datenbank abzurufen
$stmt = $pdo->prepare("SELECT * FROM `regisseur` ");

// Hinweis: Hier könnte man ggf. eine Sicherheitsabfrage mit bindValue hinzufügen, um mögliche SQL-Injektionen zu verhindern, jedoch ist sie hier nicht notwendig, da keine Parameter in der Query verwendet werden.

// Führt das vorbereitete SQL-Statement aus
$stmt->execute();

// Holt alle Datensätze als assoziatives Array
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Debugging-Hinweis (diese Zeile ist auskommentiert und kann zur Ausgabe von Ergebnissen während der Entwicklung genutzt werden):
// var_dump($results);

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Regisseur</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css"> <!-- Lädt das Stylesheet von Bootstrap -->
</head>
<body class="bg-light">
    <header class="bg-primary text-white text-center p-3">
        <a href="./../" class="text-white mx-3">Home</a>
        <a href="./../film" class="text-white mx-3">Filme</a>
        <a href="./../regisseur" class="text-white mx-3">Regisseure</a>
        <a href="./../genre" class="text-white mx-3">Genres</a>
    </header>
    
    <div class="container mt-5">
        <h1 class="text-center mb-4">Regisseur</h1> <!-- Titel der Seite -->
        
        <!-- Tabelle zur Anzeige der Regisseure -->
        <div class="table-responsive">
            <table class="table table-striped table-bordered shadow-sm">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Geburtsdatum</th>
                        <th>Nationalität</th>
                        <th>Delete</th>
                        <th>Update</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach($results as $result): ?> 
                    <tr>
                        <td><?php echo $result['id'] ?></td>
                        <td><?php echo $result['name'] ?></td>
                        <td><?php echo $result['geburtsdatum'] ?></td>
                        <td><?php echo $result['nationalitaet'] ?></td>
                        <td><a href="delete.php?deleteId=<?php echo $result['id']?>" class="btn btn-danger btn-sm"> Delete </a></td>
                        <td><a href="update.php?updateId=<?php echo $result['id']?>" class="btn btn-warning btn-sm"> Update </a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Button, um einen neuen Regisseur hinzuzufügen -->
        <div class="text-center mt-4">
            <a href="insert.php" class="btn btn-primary">Regisseur anlegen</a>
        </div>
    </div>
</body>
</html>