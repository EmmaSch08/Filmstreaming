-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 04. Apr 2025 um 12:55
-- Server-Version: 10.4.32-MariaDB
-- PHP-Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `filmstreaming`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `film`
--

CREATE TABLE `film` (
  `id` int(11) NOT NULL,
  `titel` varchar(255) DEFAULT NULL,
  `erscheinungsdatum` date DEFAULT NULL,
  `regisseur_id` int(11) DEFAULT NULL,
  `bewertung` int(11) DEFAULT NULL,
  `genre` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `film`
--

INSERT INTO `film` (`id`, `titel`, `erscheinungsdatum`, `regisseur_id`, `bewertung`, `genre`) VALUES
(1, 'Die Glückspuppe', '1934-06-01', 2, 4, 1),
(2, 'Stalk of the Celery Monster ', '1979-08-30', 1, 2, 2);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `genre`
--

CREATE TABLE `genre` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `genre`
--

INSERT INTO `genre` (`id`, `name`) VALUES
(1, 'Komödie'),
(2, 'Animation');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `regisseur`
--

CREATE TABLE `regisseur` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `geburtsdatum` date DEFAULT NULL,
  `nationalitaet` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `regisseur`
--

INSERT INTO `regisseur` (`id`, `name`, `geburtsdatum`, `nationalitaet`) VALUES
(1, 'Tim Burton', '1958-08-25', 'Amerikaner'),
(2, 'Luise Fleck', '1873-08-01', 'Österreicherin');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `film`
--
ALTER TABLE `film`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `genre`
--
ALTER TABLE `genre`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `regisseur`
--
ALTER TABLE `regisseur`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
