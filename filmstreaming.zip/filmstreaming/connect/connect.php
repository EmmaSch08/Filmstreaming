<?php

//neue Instanz der Klass PDO; dient zum Erstellen einer Verbindung zur Datenbank
try {
$pdo = new PDO('mysql:host=localhost;dbname=filmstreaming', 'root', '');
}

catch (PDOException $e){
    echo "Keine Verbindung zur Datenbank";
    die();
}