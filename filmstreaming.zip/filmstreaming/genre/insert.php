<?php

// Einbinden der Datei, die die Datenbankverbindung herstellt
require dirname(__DIR__) . '/connect/connect.php';

// Überprüfen, ob das Formular per POST-Methode abgesendet wurde
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Abrufen der Formulardaten
    $id = $_POST['id'];
    $name = $_POST['name'];

    // Debugging: ID ausgeben (nur zu Testzwecken)
    echo $id;

    // SQL-Abfrage vorbereiten, um das Genre in die Datenbank einzufügen
    $stmt = $pdo->prepare('INSERT INTO `genre` (`id`, `name`) VALUES (:id, :name)');

    // Sicherheitsvorkehrung gegen SQL-Injections durch Bindung der Eingabewerte
    $stmt->bindValue(':id', $id);
    $stmt->bindValue(':name', $name);

    // Ausführen der SQL-Abfrage
    $stmt->execute();

    // Nach dem erfolgreichen Einfügen auf die Startseite weiterleiten
    header('location:./index.php');
}

?>

<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Genre hinzufügen</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css"> <!-- Bootstrap-Styles einbinden -->
</head>
<body class="container mt-5">
    <h2 class="mb-4 text-center">Genre hinzufügen</h2>
    
    <!-- Formular zum Hinzufügen eines neuen Genres -->
    <form action="" method="POST" class="border p-4 rounded shadow">
        <a href="./../genre/" class="btn btn-primary" style="float: right; margin: 5px;">X</a>


        <!-- Eingabefeld für die ID -->
        <div class="mb-3">
            <label for="id" class="form-label">ID:</label>
            <input type="text" id="id" name="id" class="form-control" required>
        </div>

        <!-- Eingabefeld für den Namen des Genres -->
        <div class="mb-3">
            <label for="name" class="form-label">Name:</label>
            <input type="text" id="name" name="name" class="form-control" required>
        </div>

        <!-- Absenden-Button für das Formular -->
        <button type="submit" class="btn btn-primary w-100">Genre hinzufügen</button>
    </form>
</body>
</html>
