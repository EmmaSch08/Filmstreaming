<?php

// Einbinden der Datei, die die Datenbankverbindung enthält
require dirname(__DIR__) . '/connect/connect.php';

// Bereitet eine SQL-Abfrage vor, um alle Datensätze aus der Tabelle `genre` abzurufen
$stmt = $pdo->prepare("SELECT * FROM `genre` ");

// Sicherheitsfeature gegen MySQL-Injections. In diesem Fall wird es nicht verwendet, da keine Parameterbindung notwendig ist.
// $stmt->bindValue(':id', $_GET['id']); // Dies wäre nötig, wenn ein Parameter in der WHERE-Klausel verwendet werden würde.

// Führt das SQL-Statement aus, um die Ergebnisse der Abfrage zu erhalten
$stmt->execute();

// Holt alle Datensätze aus der `genre`-Tabelle als assoziatives Array
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Ausgabewerte der `genre`-Daten für Debugging-Zwecke (kann entfernt werden)
// var_dump($result);

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Genre</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css"> <!-- Einbinden von Bootstrap für das Design -->
</head>
<body class="bg-light">
    <header class="bg-primary text-white text-center p-3">
        <a href="./../" class="text-white mx-3">Home</a>
        <a href="./../film" class="text-white mx-3">Filme</a>
        <a href="./../regisseur" class="text-white mx-3">Regisseure</a>
        <a href="./../genre" class="text-white mx-3">Genres</a>
    </header>

    <div class="container mt-5">
        <h1 class="text-center mb-4">Genre</h1>
        
        <!-- Tabelle zur Anzeige der Genres -->
        <div class="table-responsive">
            <table class="table table-striped table-bordered shadow-sm">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Delete</th>
                        <th>Update</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach($results as $result): ?> 
                    <tr>
                        <td><?php echo $result['id'] ?></td>
                        <td><?php echo $result['name'] ?></td>
                        <td><a href="delete.php?deleteId=<?php echo $result['id']?>" class="btn btn-danger btn-sm"> Delete </a></td>
                        <td><a href="update.php?updateId=<?php echo $result['id']?>" class="btn btn-warning btn-sm"> Update </a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Button, um zur Seite zum Anlegen eines neuen Genres zu gelangen -->
        <div class="text-center mt-4">
            <a href="insert.php" class="btn btn-primary">Genre anlegen</a>
        </div>
    </div>
</body>
</html>
