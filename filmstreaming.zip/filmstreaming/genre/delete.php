<?php

// Einbinden der Datei, die die Datenbankverbindung enthält
require dirname(__DIR__) . '/connect/connect.php';

// Prüft, ob eine `deleteId` über die URL übergeben wurde
if(isset($_GET['deleteId'])) {
    // Wenn `deleteId` vorhanden ist, wird diese in der Variable `$id` gespeichert
    $id = $_GET['deleteId'];

    // Debugging-Ausgabe, um den Wert von `deleteId` zu prüfen (in der Realität könnte dies entfernt werden)
    echo "deleteId auf " . $id . " gesetzt";

    // Bereitet eine SQL-Abfrage vor, um den Datensatz aus der `genre`-Tabelle zu löschen
    $stmt = $pdo->prepare('DELETE FROM `genre` WHERE `id`=:id');
    
    // Bindet den Wert von `$id` an die Abfrage, um SQL-Injections zu verhindern
    $stmt->bindValue(':id', $id);

    // Führt die SQL-Abfrage aus, um den Datensatz zu löschen
    $stmt->execute();

    // Nach erfolgreichem Löschen wird der Benutzer zur Startseite weitergeleitet
    header('location:./index.php');
}

?>
