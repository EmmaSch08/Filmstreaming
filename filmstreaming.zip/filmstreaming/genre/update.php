<?php

// Verbindung zur Datenbank herstellen
require dirname(__DIR__) . '/connect/connect.php';

// Vorbefüllen der Input-Felder, wenn die "updateId" gesetzt ist
if(isset($_GET['updateId'])){
    $id = $_GET['updateId'];
    // SQL-Abfrage vorbereiten, um das Genre mit der gegebenen ID abzurufen
    $stmt = $pdo->prepare('SELECT * FROM `genre` WHERE `id`=:id');
    $stmt->bindValue(':id', $id); 
    $stmt->execute();

    // Abrufen der Genre-Daten und Befüllen der Variablen
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $name = $result['name'];  // Name des Genres
}

// Verarbeitung des Formulars nach dem Absenden
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];  // Die ID des Genres
    $name = $_POST['name'];  // Der neue Name des Genres
    
    // Ausgabe der ID (nur zu Debugging-Zwecken)
    echo $id;
    
    // SQL-Abfrage zur Aktualisierung des Genres in der Datenbank
    $stmt = $pdo->prepare('UPDATE `genre` SET `name`=:name WHERE `id`=:id');

    // Sicherheitsfeature gegen SQL-Injections durch Parameterbindung
    $stmt->bindValue(':id', $id);
    $stmt->bindValue(':name', $name);

    // Ausführen des SQL-Statements
    $stmt->execute();

    // Nach erfolgreichem Update zur Startseite weiterleiten
    header('location:./index.php');
}

?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Genre ändern</title>
    <!-- Bootstrap für das Styling einbinden -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <!-- Überschrift für die Seite -->
    <h2 class="mb-4 text-center">Genre ändern</h2>
    
    <!-- Formular zur Änderung eines Genres -->
    <form action="" method="POST" class="border p-4 rounded shadow">
        <a href="./../genre/" class="btn btn-primary" style="float: right; margin: 5px;">X</a>


        <!-- ID des Genres (nur Anzeige, nicht bearbeitbar) -->
        <div class="mb-3">
            <label for="id" class="form-label">ID:</label>
            <input type="text" id="id" name="id" class="form-control" value="<?php echo $id ?>" readonly>
        </div>
        
        <!-- Name des Genres -->
        <div class="mb-3">
            <label for="name" class="form-label">Name:</label>
            <input type="text" id="name" name="name" class="form-control" value="<?php echo $name ?>" required>
        </div>

        <!-- Button zum Absenden des Formulars -->
        <button type="submit" class="btn btn-primary w-100">Genre ändern</button>
    </form>
</body>
</html>
