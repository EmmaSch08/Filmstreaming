<?php

// Einbinden der Datenbankverbindungsdatei
require dirname(__DIR__) . '/connect/connect.php';

// SQL-Statement vorbereiten, um alle Filme mit den entsprechenden Regisseuren und Genres aus der Datenbank abzurufen
$stmt = $pdo->prepare("
    SELECT `film`.`id`, `film`.`titel`, `regisseur`.`name`, `film`.`erscheinungsdatum`, `film`.`bewertung`, `genre`.`name`
    FROM `film`
    LEFT JOIN `regisseur` ON `film`.`regisseur_id` = `regisseur`.`id`
    LEFT JOIN `genre` ON `film`.`genre` = `genre`.`id`
    ORDER BY `film`.`titel` ASC
");

// Ausführen des vorbereiteten SQL-Statements
$stmt->execute();

// Abrufen der Ergebnisse der SQL-Abfrage als assoziatives Array
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Film</title>
    <!-- Einbinden von Bootstrap für das Styling -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <header class="bg-primary text-white text-center p-3">
        <a href="./../" class="text-white mx-3">Home</a>
        <a href="./../film" class="text-white mx-3">Filme</a>
        <a href="./../regisseur" class="text-white mx-3">Regisseure</a>
        <a href="./../genre" class="text-white mx-3">Genres</a>
    </header>

    <div class="container mt-5">
        <h1 class="text-center mb-4">Film</h1>

        <!-- Tabelle, um die Filme anzuzeigen -->
        <div class="table-responsive">
            <table class="table table-striped table-bordered shadow-sm">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th>
                        <th>Titel</th>
                        <th>Erscheinungsdatum</th>
                        <th>Regisseur</th>
                        <th>Bewertung</th>
                        <th>Genre</th>
                        <th>Delete</th>
                        <th>Update</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach($results as $result): ?> 
                    <tr>
                        <td><?php echo $result['id'] ?></td>
                        <td><?php echo $result['titel'] ?></td>
                        <td><?php echo $result['erscheinungsdatum'] ?></td>
                        <td><?php echo $result['name'] ?></td>
                        <td><?php echo $result['bewertung'] ?></td>
                        <td><?php echo $result['name'] ?></td>
                        <td><a href="delete.php?deleteId=<?php echo $result['id']?>" class="btn btn-danger btn-sm"> Delete </a></td>
                        <td><a href="update.php?updateId=<?php echo $result['id']?>" class="btn btn-warning btn-sm"> Update </a></td>
                    </tr> 
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Button, um zur Seite zum Anlegen eines neuen Films zu gelangen -->
        <div class="text-center mt-4">
            <a href="insert.php" class="btn btn-primary">Film anlegen</a>
        </div>
    </div>
</body>
</html>
