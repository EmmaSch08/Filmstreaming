<?php

// Einbinden der Datei, die die Datenbankverbindung enthält
require dirname(__DIR__) . '/connect/connect.php'; 

// Prüft, ob eine Film-ID für das Update übergeben wurde
if(isset($_GET['updateId'])){
    // Wenn eine ID übergeben wurde, speichern wir sie in der Variable $id
    $id = $_GET['updateId'];

    // Bereitet eine SQL-Abfrage vor, um die Daten des Films basierend auf der ID zu laden
    $stmt = $pdo->prepare('SELECT * FROM `film` WHERE `id`=:id');
    $stmt->bindValue(':id', $id); 
    $stmt->execute();

    // Holt die Filmdaten und speichert sie in einem assoziativen Array
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    // Zuweisen der abgerufenen Werte zu Variablen
    $titel = $result['titel'];
    $erscheinungsdatum = $result['erscheinungsdatum'];
    $regisseur_id = $result['regisseur_id'];
    $bewertung = $result['bewertung'];
    $genre = $result['genre'];
}

// Wenn das Formular abgesendet wird, verarbeiten wir die Daten für das Update
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Abrufen der Formulardaten
    $id = $_POST['id'];
    $titel = $_POST['titel'];
    $erscheinungsdatum = $_POST['erscheinungsdatum'];
    $regisseur_id = $_POST['regisseur_id'];
    $bewertung = $_POST['bewertung'];
    $genre = $_POST['genre'];
    
    // Vorbereiten des SQL-Statements, um die Filmdaten zu aktualisieren
    $stmt = $pdo->prepare('UPDATE `film` SET `titel`=:titel, `erscheinungsdatum`=:erscheinungsdatum, 
                           `regisseur_id`=:regisseur_id, `bewertung`=:bewertung, `genre`=:genre WHERE `id`=:id');

    // Bindung der Formulardaten an die SQL-Abfrage, um SQL-Injections zu verhindern
    $stmt->bindValue(':id', $id);
    $stmt->bindValue(':titel', $titel);
    $stmt->bindValue(':erscheinungsdatum', $erscheinungsdatum);
    $stmt->bindValue(':regisseur_id', $regisseur_id);
    $stmt->bindValue(':bewertung', $bewertung);
    $stmt->bindValue(':genre', $genre);

    // Ausführen des SQL-Statements, um den Film zu aktualisieren
    $stmt->execute();

    // Weiterleitung zur Startseite nach erfolgreichem Update
    header('location:./index.php');
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Film ändern</title>
    <!-- Einbinden von Bootstrap für das Styling der Seite -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <!-- Überschrift für die Seite -->
    <h2 class="mb-4">Film ändern</h2>
    
    <!-- Formular zum Bearbeiten eines Films -->
    <form action="" method="POST" class="border p-4 rounded shadow">
        <a href="./../film/" class="btn btn-primary" style="float: right; margin: 5px;">X</a>


        <!-- ID des Films (wird nur angezeigt, aber nicht bearbeitet) -->
        <div class="mb-3">
            <label for="id" class="form-label">ID:</label>
            <input type="text" id="id" name="id" class="form-control" value="<?php echo $id ?>" readonly>
        </div>
        
        <!-- Titel des Films -->
        <div class="mb-3">
            <label for="titel" class="form-label">Titel:</label>
            <input type="text" id="titel" name="titel" class="form-control" value="<?php echo $titel ?>" required>
        </div>

        <!-- Erscheinungsdatum des Films -->
        <div class="mb-3">
            <label for="erscheinungsdatum" class="form-label">Erscheinungsdatum:</label>
            <input type="date" id="erscheinungsdatum" name="erscheinungsdatum" class="form-control" value="<?php echo $erscheinungsdatum ?>" required>
        </div>

        <!-- Auswahl des Regisseurs für den Film -->
        <div class="mb-3">
            <label for="regisseur_id" class="form-label">Regisseur:</label>
            <select id="regisseur_id" name="regisseur_id" class="form-control">
                <option value="">Bitte wählen</option>
                <!-- Durchlaufen der Regisseure, die in der Datenbank gespeichert sind -->
                <?php foreach($result_regisseur as $result): ?>
                <option value="<?php echo $result['id']?>" <?php echo ($result['id'] == $regisseur_id) ? 'selected' : ''; ?>><?php echo $result['name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Bewertung des Films -->
        <div class="mb-3">
            <label for="bewertung" class="form-label">Bewertung:</label>
            <input type="text" id="bewertung" name="bewertung" class="form-control" value="<?php echo $bewertung ?>" required>
        </div>

        <!-- Auswahl des Genres für den Film -->
        <div class="mb-3">
            <label for="genre" class="form-label">Genre:</label>
            <select id="genre" name="genre" class="form-control">
                <option value="">Bitte wählen</option>
                <!-- Durchlaufen der Genres, die in der Datenbank gespeichert sind -->
                <?php foreach($result_genre as $result): ?>
                <option value="<?php echo $result['id']?>" <?php echo ($result['id'] == $genre) ? 'selected' : ''; ?>><?php echo $result['name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Button zum Absenden des Formulars -->
        <button type="submit" class="btn btn-primary">Film ändern</button>
    </form>
</body>
</html>
