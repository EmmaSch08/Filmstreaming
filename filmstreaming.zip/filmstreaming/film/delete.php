<?php

require dirname(__DIR__) . '/connect/connect.php'; // Verbindung zur Datenbank herstellen

// Überprüfung, ob eine Film-ID zum Löschen übergeben wurde
if(isset($_GET['deleteId'])) {
    $id = $_GET['deleteId']; // Speichern der übergebenen ID
    echo "deleteId auf " . $id . " gesetzt"; // Debugging-Ausgabe
    
    // Vorbereiten des SQL-Statements zum Löschen eines Films
    $stmt = $pdo->prepare('DELETE FROM `film` WHERE `id`=:id');
    
    // Binden der Parameter zur Vermeidung von SQL-Injection
    $stmt->bindValue(':id', $id);
    
    // Ausführen des Statements
    $stmt->execute();

    // Nach erfolgreichem Löschen zurück zur Hauptseite weiterleiten
    header('location:./index.php');
}

?>