<?php

// Verbindung zur Datenbank herstellen, indem die Datei 'connect.php' eingebunden wird
require dirname(__DIR__) . '/connect/connect.php'; 

// Abrufen aller Regisseure aus der Datenbank
$stmt = $pdo->prepare('SELECT * FROM `regisseur`');
$stmt->execute();
$result_regisseur = $stmt->fetchAll(PDO::FETCH_ASSOC); // Alle Regisseure werden in einem Array gespeichert

// Abrufen aller Genres aus der Datenbank
$stmt = $pdo->prepare('SELECT * FROM `genre`');
$stmt->execute();
$result_genre = $stmt->fetchAll(PDO::FETCH_ASSOC); // Alle Genres werden in einem Array gespeichert

// Überprüfung, ob das Formular abgesendet wurde (über POST-Request)
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Abrufen der Formulardaten
    $id = $_POST['id']; // Film-ID
    $titel = $_POST['titel']; // Filmtitel
    $erscheinungsdatum = $_POST['erscheinungsdatum']; // Erscheinungsdatum des Films
    $regisseur_id = $_POST['regisseur_id']; // ID des Regisseurs
    $bewertung = $_POST['bewertung']; // Bewertung des Films
    $genre = $_POST['genre']; // Genre des Films
    
    // Debugging-Ausgabe der Film-ID
    echo $id;

    // SQL-Statement zum Einfügen eines neuen Films in die Datenbank
    $stmt = $pdo->prepare('INSERT INTO `film` (`id`, `titel`, `erscheinungsdatum`, `regisseur_id`, `bewertung`, `genre`) 
                           VALUES (:id, :titel, :erscheinungsdatum, :regisseur_id, :bewertung, :genre)');

    // Bindung der Formulardaten an die SQL-Parameter, um SQL-Injection zu verhindern
    $stmt->bindValue(':id', $id);
    $stmt->bindValue(':titel', $titel);
    $stmt->bindValue(':erscheinungsdatum', $erscheinungsdatum);
    $stmt->bindValue(':regisseur_id', $regisseur_id);
    $stmt->bindValue(':bewertung', $bewertung);
    $stmt->bindValue(':genre', $genre);

    // Ausführen des SQL-Statements, um die Daten in die Tabelle 'film' einzufügen
    $stmt->execute();

    // Nach erfolgreichem Einfügen zur Startseite (index.php) weiterleiten
    header('location:./index.php');
}

?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Film hinzufügen</title>
    <!-- Einbinden der Bootstrap-CSS für das Styling -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2 class="mb-4">Film hinzufügen</h2>
    
    <!-- HTML-Formular zur Eingabe eines Films -->
    <form action="" method="POST" class="border p-4 rounded shadow">
        <a href="./../film/" class="btn btn-primary" style="float: right; margin: 5px;">X</a>
        
        <!-- Eingabefeld für die Film-ID -->
        <div class="mb-3">
            <label for="id" class="form-label">ID:</label>
            <input type="text" id="id" name="id" class="form-control" required>
        </div>

        <!-- Eingabefeld für den Filmtitel -->
        <div class="mb-3">
            <label for="titel" class="form-label">Titel:</label>
            <input type="text" id="titel" name="titel" class="form-control" required>
        </div>

        <!-- Eingabefeld für das Erscheinungsdatum -->
        <div class="mb-3">
            <label for="erscheinungsdatum" class="form-label">Erscheinungsdatum:</label>
            <input type="date" id="erscheinungsdatum" name="erscheinungsdatum" class="form-control" required>
        </div>

        <!-- Dropdown-Menü zur Auswahl des Regisseurs -->
        <div class="mb-3">
            <label for="regisseur_id" class="form-label">Regisseur:</label>
            <select id="regisseur_id" name="regisseur_id" class="form-control">
                <option value="">Bitte wählen</option>
                <!-- Durchlaufen der Regisseure aus der Datenbank und Hinzufügen der Optionen zum Dropdown -->
                <?php foreach($result_regisseur as $result): ?>
                <option value="<?php echo $result['id']?>"><?php echo $result['name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Eingabefeld für die Bewertung des Films -->
        <div class="mb-3">
            <label for="bewertung" class="form-label">Bewertung:</label>
            <input type="text" id="bewertung" name="bewertung" class="form-control" required>
        </div>

        <!-- Dropdown-Menü zur Auswahl des Genres -->
        <div class="mb-3">
            <label for="genre" class="form-label">Genre:</label>
            <select id="genre" name="genre" class="form-control">
                <option value="">Bitte wählen</option>
                <!-- Durchlaufen der Genres aus der Datenbank und Hinzufügen der Optionen zum Dropdown -->
                <?php foreach($result_genre as $result): ?>
                <option value="<?php echo $result['id']?>"><?php echo $result['name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Absenden-Button für das Formular -->
        <button type="submit" class="btn btn-primary">Film hinzufügen</button>
    </form>
</body>
</html>