<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
</head>
<body>
    <header class="bg-primary text-white text-center p-3">
        <a href="./" class="text-white mx-3">Home</a>
        <a href="./film" class="text-white mx-3">Filme</a>
        <a href="./regisseur" class="text-white mx-3">Regisseure</a>
        <a href="./genre" class="text-white mx-3">Genres</a>
    </header>
</body>
</html>